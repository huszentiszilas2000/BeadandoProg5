package hu.mik.zh.reactive.controller;

import hu.mik.zh.reactive.document.Pet;
import hu.mik.zh.reactive.document.PetSpecies;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface PetController {

    Mono<Pet> save(Pet pet);

    Flux<Pet> listAll();

    Mono<Pet> findById(String id);

    Mono<Void> delete(String id);

    Flux<Pet> findBySpecies(PetSpecies species);

    Flux<PetSpecies> getSpeciesName();

}
