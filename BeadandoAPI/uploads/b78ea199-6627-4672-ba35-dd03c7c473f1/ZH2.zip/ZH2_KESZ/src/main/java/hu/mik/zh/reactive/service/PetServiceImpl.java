package hu.mik.zh.reactive.service;

import hu.mik.zh.reactive.document.Pet;
import hu.mik.zh.reactive.document.PetSpecies;
import hu.mik.zh.reactive.repository.PetRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class PetServiceImpl implements PetService{

    private final PetRepository petRepository;

    @Override
    public Mono<Pet> save(Pet pet) {
        return petRepository.save(pet);
    }

    @Override
    public Mono<Pet> findById(String id) {
        return petRepository.findById(id);
    }

    @Override
    public Mono<Void> delete(String id) {
        return petRepository.deleteById(id);
    }

    @Override
    public Flux<Pet> findBySpecies(PetSpecies species) {
        return petRepository.findAll(Example.of(new Pet(null, null, species)));
    }

    @Override
    public Flux<Pet> listAll() {
        return petRepository.findAll();
    }

    @Override
    public Flux<PetSpecies> getSpecies() {
        return Flux.fromArray(PetSpecies.values());
    }

}
