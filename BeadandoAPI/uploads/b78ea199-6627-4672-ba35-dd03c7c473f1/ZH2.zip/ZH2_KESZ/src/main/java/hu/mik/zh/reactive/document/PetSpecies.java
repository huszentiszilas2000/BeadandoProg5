package hu.mik.zh.reactive.document;

public enum PetSpecies {

    CAT, DOG, PARROT, TURTLE, FERRET;

}
