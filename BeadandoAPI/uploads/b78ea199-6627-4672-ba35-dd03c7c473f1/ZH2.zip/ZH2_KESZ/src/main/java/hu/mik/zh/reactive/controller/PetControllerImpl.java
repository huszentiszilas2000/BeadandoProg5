package hu.mik.zh.reactive.controller;

import hu.mik.zh.reactive.document.Pet;
import hu.mik.zh.reactive.document.PetSpecies;
import hu.mik.zh.reactive.service.PetService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
public class PetControllerImpl implements PetController{

    private final PetService petService;

    @Override
    @ResponseStatus(HttpStatus.OK)
    @PutMapping("/api/pet")
    public Mono<Pet> save(@RequestBody Pet pet) {
        return petService.save(pet);
    }

    @Override
    @GetMapping("/api/pet")
    @ResponseStatus(HttpStatus.OK)
    public Flux<Pet> listAll() {
        return petService.listAll();
    }

    @Override
    @GetMapping("/api/pet/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Pet> findById(@PathVariable String id) {
        return petService.findById(id);
    }

    @Override
    @DeleteMapping("/api/pet/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Void> delete(@PathVariable String id) {
        return petService.delete(id);
    }

    @Override
    public Flux<Pet> findBySpecies(PetSpecies species) {
        return null;
    }

    @Override
    @GetMapping("/api/pet/species")
    @ResponseStatus(HttpStatus.OK)
    public Flux<PetSpecies> getSpeciesName() {
        return petService.getSpecies();
    }
}
