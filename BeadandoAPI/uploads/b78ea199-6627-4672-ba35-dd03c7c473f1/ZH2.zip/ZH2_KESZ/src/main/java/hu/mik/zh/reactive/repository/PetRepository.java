package hu.mik.zh.reactive.repository;

import hu.mik.zh.reactive.document.Pet;
import hu.mik.zh.reactive.document.PetSpecies;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ResponseStatus;
import reactor.core.publisher.Flux;

@Repository
public interface PetRepository extends ReactiveMongoRepository<Pet, String> {

}
