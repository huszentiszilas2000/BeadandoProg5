package hu.mik.zh.reactive.document;

import org.springframework.data.annotation.Id;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document
public class Pet {

    public Pet(String uid, String name, PetSpecies species) {
        this.uid = uid;
        this.name = name;
        this.species = species;
    }

    public Pet() {}

    @Id
    private String uid;
    private String name;
    private PetSpecies species;

}
