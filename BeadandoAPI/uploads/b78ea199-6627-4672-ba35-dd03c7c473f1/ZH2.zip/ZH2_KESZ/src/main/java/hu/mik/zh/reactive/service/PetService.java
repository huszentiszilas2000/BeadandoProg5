package hu.mik.zh.reactive.service;

import hu.mik.zh.reactive.document.Pet;
import hu.mik.zh.reactive.document.PetSpecies;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface PetService {

    Mono<Pet> save(Pet pet);

    Mono<Pet> findById(String id);

    Mono<Void> delete(String id);

    Flux<Pet> findBySpecies(PetSpecies species);

    Flux<Pet> listAll();

    Flux<PetSpecies> getSpecies();

}
