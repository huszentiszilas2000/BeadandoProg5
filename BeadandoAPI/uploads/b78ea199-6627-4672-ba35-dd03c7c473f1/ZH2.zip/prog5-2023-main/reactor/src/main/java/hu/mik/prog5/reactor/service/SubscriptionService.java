package hu.mik.prog5.reactor.service;

import hu.mik.prog5.reactor.entity.Subscription;
import hu.mik.prog5.reactor.repository.SubscriptionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@RequiredArgsConstructor
public class SubscriptionService {

    private final SubscriptionRepository subscriptionRepository;

    public Flux<Subscription> findAll() {
        return this.subscriptionRepository.findAll();
    }

}
