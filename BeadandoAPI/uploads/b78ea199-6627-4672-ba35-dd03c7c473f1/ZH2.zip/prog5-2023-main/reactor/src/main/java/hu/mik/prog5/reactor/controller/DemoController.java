package hu.mik.prog5.reactor.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;

@Slf4j
@RestController
public class DemoController {

    private final WebClient client = WebClient.builder()
                                              .clientConnector(new ReactorClientHttpConnector())
                                              .build();

    @GetMapping("/test")
    public Flux<String> testEndpoint() {
        return Flux.just("asd1", "asd2", "asd3", "asd4")
                   .map(String::toUpperCase)
                   .filter(s -> !"asd4".equals(s))
                   .flatMap(this::remoteServiceCall)
                   .thenMany(this.remoteServiceCall2())
                   .filter(s -> false)
                   .switchIfEmpty(Mono.error(RuntimeException::new))
                   .delayElements(Duration.ofSeconds(3))
                   .subscribeOn(Schedulers.parallel())
                   .publishOn(Schedulers.parallel(), 2)
                   .log();
    }

    @GetMapping("/test2")
    public Mono<String> test2() {
        //return Mono.just("FooBar")
        //           .flatMap(fooBar -> this.remoteServiceCall(fooBar)
        //                                  .flatMap(response -> this.remoteServiceCall(fooBar)
        //                                                           .map(response2 -> response + response2)));
        return Mono.just("FooBar")
                   .flatMap(fooBar ->
                           Mono.zip(
                                   this.remoteServiceCall(fooBar),
                                   this.remoteServiceCall(fooBar),
                                   (response1, response2) -> response1 + response2));
    }


    @GetMapping("/test3")
    public Mono<Void> test3() {
        return this.client.get()
                          .uri("https://google.com")
                          .retrieve()
                          .toBodilessEntity()
                          .map(ResponseEntity::toString)
                          .then();
    }

    private Flux<String> empty() {
        return Flux.just("empty1", "empty2");
    }

    private Flux<String> remoteServiceCall2() {
        log.info("remoteServiceCall2");
        return Flux.just("FooBar", "GooBar");
    }


    private Mono<String> remoteServiceCall(String input) {
        return Mono.just(input + "!_!");
    }

}
