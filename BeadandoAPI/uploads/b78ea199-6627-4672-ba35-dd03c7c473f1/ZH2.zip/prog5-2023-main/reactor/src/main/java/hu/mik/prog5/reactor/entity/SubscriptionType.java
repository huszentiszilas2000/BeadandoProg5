package hu.mik.prog5.reactor.entity;

public enum SubscriptionType {

    ALL_EMAILS,
    DAILY_DIGEST

}
