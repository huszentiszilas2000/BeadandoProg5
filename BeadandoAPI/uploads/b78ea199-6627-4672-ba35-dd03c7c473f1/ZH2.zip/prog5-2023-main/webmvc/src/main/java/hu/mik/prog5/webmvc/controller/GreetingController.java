package hu.mik.prog5.webmvc.controller;

import hu.mik.prog5.webmvc.controller.exception.IAmATeapotException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class GreetingController {

    @GetMapping("/greeting")
    //@RequestMapping(path = "/greeting", method = RequestMethod.GET)
    public String greet(Model model, @RequestParam(defaultValue = "FooBar") String name) {
        model.addAttribute("name", name);
        return "greeting";
    }

    @GetMapping("/greeting/{name}")
    public String greetFromPath(Model model, @PathVariable String name) {
        model.addAttribute("name", name);
        return "greeting";
    }

    @GetMapping("/forward")
    public String forward() {
        return "forward:greeting";
    }

    @GetMapping("/redirect")
    public String redirect(){
        return "redirect:greeting";
    }

    @ResponseBody
    //@ResponseStatus(HttpStatus.BAD_REQUEST)
    @GetMapping("/hello-world")
    public String helloWorld() {
        throw new IAmATeapotException("FoBar");
        //return "Hello World!";
    }

}
