package hu.mik.prog5.webmvc.controller.adviser;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

    @ExceptionHandler(Exception.class)
    public ModelAndView defaultErrorHandler(Exception exception) {
        var status = Optional.ofNullable(AnnotationUtils.findAnnotation(exception.getClass(), ResponseStatus.class))
                             .map(ResponseStatus::code)
                             .orElse(HttpStatus.INTERNAL_SERVER_ERROR);

        return new ModelAndView("error/error_page", status)
                .addObject("status", status.value() + " - " + status.getReasonPhrase())
                .addObject("timestamp", DTF.format(LocalDateTime.now()))
                .addObject("exception", exception.getClass())
                .addObject("message", exception.getMessage());
    }

}
