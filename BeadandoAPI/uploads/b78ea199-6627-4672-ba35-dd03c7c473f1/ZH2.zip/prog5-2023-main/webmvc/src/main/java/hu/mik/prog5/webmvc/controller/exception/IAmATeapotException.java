package hu.mik.prog5.webmvc.controller.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.I_AM_A_TEAPOT)
public class IAmATeapotException extends RuntimeException {

    public IAmATeapotException() {
    }

    public IAmATeapotException(String message) {
        super(message);
    }

    public IAmATeapotException(String message, Throwable cause) {
        super(message, cause);
    }

    public IAmATeapotException(Throwable cause) {
        super(cause);
    }

    public IAmATeapotException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
