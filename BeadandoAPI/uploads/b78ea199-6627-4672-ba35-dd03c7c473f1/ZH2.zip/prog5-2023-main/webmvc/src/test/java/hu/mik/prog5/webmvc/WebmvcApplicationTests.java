package hu.mik.prog5.webmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
