package hu.mik.prog5.demo.config;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;

//@Getter
//@RequiredArgsConstructor
@ConfigurationProperties(prefix = "console.config")
public record AppConfig(String name) {

    //private final String name;

    //public AppConfig(String name) {
    //    this.name = name;
    //}

    //public String getName() {
    //    return this.name;
    //}

}
