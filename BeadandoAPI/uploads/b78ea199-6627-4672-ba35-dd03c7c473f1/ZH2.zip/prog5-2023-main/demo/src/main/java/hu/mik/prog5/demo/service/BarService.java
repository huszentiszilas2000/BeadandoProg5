package hu.mik.prog5.demo.service;

import hu.mik.prog5.demo.config.AppConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Slf4j
@Service("bar")
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@RequiredArgsConstructor
public class BarService implements DemoService {

    private final AppConfig appConfig;

    @Override
    public void sayHello(String name) {
        log.debug(this.appConfig.name());
        log.info("bar: " + name);
    }

}
