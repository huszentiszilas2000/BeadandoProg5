package hu.mik.prog5.demo.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service("foo")
public class FooService implements DemoService {

    @Override
    public void sayHello(String name) {
        log.info("foo: " + name);
    }

}
