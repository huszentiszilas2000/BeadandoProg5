package hu.mik.prog5.demo.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Objects;

@Slf4j
@Aspect
@Component
public class DemoAspect {

    @Pointcut("execution(* hu.mik.prog5.demo.service.*.*(..))")
    public void everyCall(){}

    @Around("everyCall()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info("signature: " + joinPoint.getSignature());
        log.info("Args: " + Arrays.toString(joinPoint.getArgs()));

        var result = joinPoint.proceed();

        log.info("result: " + result);
        return result;
    }

}
