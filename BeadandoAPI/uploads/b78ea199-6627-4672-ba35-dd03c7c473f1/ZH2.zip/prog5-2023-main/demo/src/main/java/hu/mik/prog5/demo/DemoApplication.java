package hu.mik.prog5.demo;

import hu.mik.prog5.demo.service.BarService;
import hu.mik.prog5.demo.service.DemoService;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.ApplicationContext;

@Slf4j
@SpringBootApplication
@ConfigurationPropertiesScan("hu.mik.prog5.demo.config")
//@RequiredArgsConstructor
public class DemoApplication implements CommandLineRunner, InitializingBean {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	//@Autowired
	private final DemoService demoService;
	private final ApplicationContext context;

	@Value("${console.config.name}")
	public String name;

	//@Autowired
	public DemoApplication(@Qualifier("bar") DemoService demoService, @Qualifier("name") String name, ApplicationContext context) {
		this.demoService = demoService;
		this.context = context;
		log.info("DemoApplication");
		log.debug(name);
	}

	@PostConstruct
	public void init() {
		log.info("PostConstruct");
		log.info("Value: " + this.name);

		log.info(Boolean.toString(this.context.getBean(BarService.class) == this.context.getBean(BarService.class)));
	}

	//@Autowired
	//public void setFooService(FooService fooService) {
	//	this.fooService = fooService;
	//}

	@Override
	public void run(String... args) throws Exception {
		this.demoService.sayHello("It's alive!!!");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		log.info("afterPropertiesSet");
	}

}
