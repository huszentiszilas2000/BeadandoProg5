package hu.mik.prog5.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CustomBeanConfig {

    @Bean("name")
    public String getName(){
        return "FooBarName";
    }

}



