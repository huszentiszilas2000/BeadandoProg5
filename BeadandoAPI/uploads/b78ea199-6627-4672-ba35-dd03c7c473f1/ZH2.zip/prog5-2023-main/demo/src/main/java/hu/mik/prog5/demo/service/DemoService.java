package hu.mik.prog5.demo.service;

public interface DemoService {

    void sayHello(String name);

}
