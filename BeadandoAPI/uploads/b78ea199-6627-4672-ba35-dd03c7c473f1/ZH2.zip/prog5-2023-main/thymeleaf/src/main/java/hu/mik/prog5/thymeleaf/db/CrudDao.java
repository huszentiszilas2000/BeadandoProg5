package hu.mik.prog5.thymeleaf.db;

import java.util.List;

public interface CrudDao<T, ID> {

    T create(T type);

    T findById(ID id);

    List<T> findAll();

    T update(T type);

    boolean delete(ID id);

}
