package hu.mik.prog5.thymeleaf.entity;

public enum SubscriptionType {
    ALL_EMAILS,
    DAILY_DIGEST
}
