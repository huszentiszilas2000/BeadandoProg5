package hu.mik.prog5.thymeleaf.controller;

import hu.mik.prog5.thymeleaf.service.NameService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Controller
@RequiredArgsConstructor
public class HelloWorldController {

    private final NameService nameService;

    //@Secured("ROLE_ADMIN")
    //@RolesAllowed("ADMIN")
    @GetMapping("/helloWorld")
    public String helloWorld(@RequestParam(value = "name", defaultValue = "World") String name, Model model) {
        log.info(this.nameService.toUpperCase(name));
        log.info(this.nameService.toLowerCase(name));
        log.info(this.nameService.join(new ArrayList<>(List.of("name1", "name2", "admin", "user", "name3")), ", "));
        log.info(this.nameService.getAllUsernamesExceptCurrent()
                                 .toString());
        model.addAttribute("name", name);
        return "helloWorld";
    }

}
