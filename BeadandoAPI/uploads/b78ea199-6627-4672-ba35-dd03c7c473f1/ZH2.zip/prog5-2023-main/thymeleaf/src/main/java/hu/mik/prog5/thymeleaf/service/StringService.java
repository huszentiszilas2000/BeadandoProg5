package hu.mik.prog5.thymeleaf.service;

import org.springframework.stereotype.Service;

@Service
public class StringService {

    public String toUpperCase(String str) {
        if (str == null) {
            return null;
        } else {
            return str.toUpperCase();
        }
    }

}
