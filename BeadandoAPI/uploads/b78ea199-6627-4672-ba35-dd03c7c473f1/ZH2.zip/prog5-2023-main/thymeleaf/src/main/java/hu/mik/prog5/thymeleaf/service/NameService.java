package hu.mik.prog5.thymeleaf.service;

import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.access.prepost.PreFilter;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class NameService {

    //@PreAuthorize("hasRole('ADMIN')")
    @PreAuthorize("#name != authentication.principal.username")
    public String toUpperCase(String name) {
        return name.toUpperCase();
    }

    @PostAuthorize("returnObject != authentication.principal.username")
    public String toLowerCase(String name) {
        return name.toLowerCase();
    }

    @PreFilter(value = "filterObject != authentication.principal.username", filterTarget = "names")
    public String join(List<String> names, String delimiter) {
        return String.join(delimiter, names);
    }

    @PostFilter("filterObject != authentication.principal.username")
    public List<String> getAllUsernamesExceptCurrent() {
        return new ArrayList<>(List.of("admin", "user", "name1", "name2"));
    }

}
