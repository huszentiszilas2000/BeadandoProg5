package hu.mik.prog5.thymeleaf.service;

import hu.mik.prog5.thymeleaf.db.SubscriptionDao;
import hu.mik.prog5.thymeleaf.entity.Subscription;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class SubscriptionService {

    private final SubscriptionDao subscriptionDao;

    public Subscription create(Subscription subscription) {
        return this.subscriptionDao.create(subscription);
    }

}
