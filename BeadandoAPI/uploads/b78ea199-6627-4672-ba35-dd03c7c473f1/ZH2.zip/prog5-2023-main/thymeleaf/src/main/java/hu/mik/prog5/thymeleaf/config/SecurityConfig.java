package hu.mik.prog5.thymeleaf.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain configure(HttpSecurity http) throws Exception {
        return http.authorizeHttpRequests(custimizer -> custimizer.requestMatchers("/css/**", "/js/**", "/images/**", "/favicon.ico**")
                                                                  .permitAll()
                                                                  //.requestMatchers("/helloWorld")
                                                                  //.hasRole("ADMIN")
                                                                  .anyRequest()
                                                                  .authenticated())
                   .formLogin(customizer -> customizer.loginPage("/login")
                                                      .defaultSuccessUrl("/subscribe")
                                                      .permitAll())
                   .logout(Customizer.withDefaults())
                   .build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
        return new InMemoryUserDetailsManager(
                User.builder()
                    .passwordEncoder(passwordEncoder::encode)
                    .username("user")
                    .password("Password111")
                    .roles("USER")
                    .build(),
                User.builder()
                    .passwordEncoder(passwordEncoder::encode)
                    .username("admin")
                    .password("Password111")
                    .roles("USER", "ADMIN")
                    .build()
        );
    }

}
