package hu.mik.prog5.thymeleaf.db;

import hu.mik.prog5.thymeleaf.entity.Subscription;
import hu.mik.prog5.thymeleaf.rowmapper.SubscriptionRowMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementCreatorFactory;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class SubscriptionDao implements CrudDao<Subscription, Long> {

    private final JdbcTemplate jdbcTemplate;
    private final SubscriptionRowMapper rowMapper;

    @Override
    public Subscription create(Subscription subscription) {
        GeneratedKeyHolder generatedKeyHolder = new GeneratedKeyHolder();

        this.jdbcTemplate.update(connection -> {
            PreparedStatementCreatorFactory pscf = new PreparedStatementCreatorFactory("INSERT INTO subscription (email, type) values (?, ?)", Types.VARCHAR, Types.VARCHAR);

            pscf.setReturnGeneratedKeys(true);

            PreparedStatementCreator psc = pscf.newPreparedStatementCreator(List.of(subscription.getEmail(), subscription.getSubscriptionType()
                                                                                                                         .toString()));

            return psc.createPreparedStatement(connection);
        }, generatedKeyHolder);

        return this.findById(((Integer) generatedKeyHolder.getKeys()
                                                          .get("id")).longValue());
    }

    @Override
    public Subscription findById(Long id) {
        return this.jdbcTemplate.queryForObject("SELECT s.id, s.email, s.type FROM subscription s WHERE s.id = ?", this.rowMapper, id);
    }

    @Override
    public List<Subscription> findAll() {
        return this.jdbcTemplate.query("SELECT s.id, s.email, s.type FROM subscription s", this.rowMapper);
    }

    @Override
    public Subscription update(Subscription subscription) {
        this.jdbcTemplate.update("UPDATE subscription set email = ?, type = ? WHERE id = ?", subscription.getEmail(), subscription.getSubscriptionType(), subscription.getId());
        return this.findById(subscription.getId());
    }

    @Override
    public boolean delete(Long id) {
        return this.jdbcTemplate.update("DELETE FROM subscription WHERE id = ?", id) == 1;
    }

}
