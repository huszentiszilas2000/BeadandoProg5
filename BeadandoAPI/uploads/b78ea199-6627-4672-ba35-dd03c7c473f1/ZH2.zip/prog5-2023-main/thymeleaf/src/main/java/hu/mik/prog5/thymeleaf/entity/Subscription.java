package hu.mik.prog5.thymeleaf.entity;

import lombok.Data;

@Data
public class Subscription {

    private Long id;
    private String email;
    private SubscriptionType subscriptionType = SubscriptionType.ALL_EMAILS;

}
