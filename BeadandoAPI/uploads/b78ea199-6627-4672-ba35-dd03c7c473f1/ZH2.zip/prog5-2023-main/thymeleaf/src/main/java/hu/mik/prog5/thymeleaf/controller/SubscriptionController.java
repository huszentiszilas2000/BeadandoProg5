package hu.mik.prog5.thymeleaf.controller;

import hu.mik.prog5.thymeleaf.entity.Subscription;
import hu.mik.prog5.thymeleaf.entity.SubscriptionType;
import hu.mik.prog5.thymeleaf.service.SubscriptionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Slf4j
@Controller
@RequiredArgsConstructor
public class SubscriptionController {

    private final SubscriptionService subscriptionService;

    @ModelAttribute("allTypes")
    public SubscriptionType[] populateTypes() {
        return SubscriptionType.values();
    }

    @GetMapping("/subscribe")
    public String showSubscriptionForm(@ModelAttribute Subscription subscription) {
        return "subscribe";
    }

    @PostMapping("/subscribe")
    public String subscribe(@ModelAttribute Subscription subscription) {
        this.subscriptionService.create(subscription);
        log.info("Subscription: {}", subscription);
        return "redirect:subscribe";
    }

}
