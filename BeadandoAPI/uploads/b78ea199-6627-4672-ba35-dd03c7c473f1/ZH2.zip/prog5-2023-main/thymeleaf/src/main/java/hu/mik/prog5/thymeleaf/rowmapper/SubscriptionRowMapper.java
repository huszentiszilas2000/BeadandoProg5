package hu.mik.prog5.thymeleaf.rowmapper;

import hu.mik.prog5.thymeleaf.entity.Subscription;
import hu.mik.prog5.thymeleaf.entity.SubscriptionType;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class SubscriptionRowMapper implements RowMapper<Subscription> {

    @Override
    public Subscription mapRow(ResultSet rs, int rowNum) throws SQLException {
        Subscription subscription = new Subscription();

        subscription.setId(rs.getLong("id"));
        subscription.setEmail(rs.getString("email"));
        subscription.setSubscriptionType(SubscriptionType.valueOf(rs.getString("type")));
        return subscription;
    }

}
