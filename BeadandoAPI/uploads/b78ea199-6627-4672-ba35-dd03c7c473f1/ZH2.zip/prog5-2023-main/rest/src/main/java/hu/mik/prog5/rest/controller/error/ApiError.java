package hu.mik.prog5.rest.controller.error;

import java.time.LocalDateTime;

public record ApiError(LocalDateTime timestamp, String errorMsg, String path) {}
