package hu.mik.prog5.rest.exception;

public class IAmATeapotException extends RuntimeException {

    public IAmATeapotException() {
    }

    public IAmATeapotException(String message) {
        super(message);
    }

    public IAmATeapotException(String message, Throwable cause) {
        super(message, cause);
    }

    public IAmATeapotException(Throwable cause) {
        super(cause);
    }

    public IAmATeapotException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
