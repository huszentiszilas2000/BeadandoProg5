package hu.mik.prog5.rest.entinty;

public enum SubscriptionType {

    ALL_EMAILS,
    DAILY_DIGEST

}
