package hu.mik.prog5.rest.controller.error;

import hu.mik.prog5.rest.exception.IAmATeapotException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;

@ControllerAdvice
public class RestControllerAdvisor extends ResponseEntityExceptionHandler {

    @ExceptionHandler(IAmATeapotException.class)
    protected ResponseEntity<Object> handleTeapotException(IAmATeapotException ex, ServletWebRequest request) {
        var path = request.getRequest()
                          .getRequestURI();
        var body = new ApiError(LocalDateTime.now(), "Sorry, I am a teapot!", path);
        return this.handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.I_AM_A_TEAPOT, request);
    }

    @ExceptionHandler(Exception.class)
    protected ResponseEntity<Object> handleGeneric(Exception ex, ServletWebRequest request) {
        var path = request.getRequest()
                          .getRequestURI();
        var body = new ApiError(LocalDateTime.now(), ex.getMessage(), path);

        return this.handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

}
