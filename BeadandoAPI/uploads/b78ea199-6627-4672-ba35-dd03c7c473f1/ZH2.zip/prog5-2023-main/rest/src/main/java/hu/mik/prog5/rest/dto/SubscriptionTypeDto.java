package hu.mik.prog5.rest.dto;

public enum SubscriptionTypeDto {

    ALL_EMAILS,
    DAILY_DIGEST

}
