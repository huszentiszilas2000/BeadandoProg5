package hu.mik.prog5.rest.controller.service;

import hu.mik.prog5.rest.dto.SubscriptionDto;
import hu.mik.prog5.rest.mapping.SubscriptionMapper;
import hu.mik.prog5.rest.service.SubscriptionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SubscriptionControllerService {

    private final SubscriptionService service;
    private final SubscriptionMapper mapper;

    public SubscriptionDto save(SubscriptionDto subscriptionDto) {
        var entity = this.mapper.toEntity(subscriptionDto);
        entity = this.service.save(entity);
        return this.mapper.toDto(entity);
    }

}
