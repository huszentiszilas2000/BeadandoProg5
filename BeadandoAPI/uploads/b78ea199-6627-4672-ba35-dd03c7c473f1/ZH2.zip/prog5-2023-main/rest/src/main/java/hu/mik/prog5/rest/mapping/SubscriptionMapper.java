package hu.mik.prog5.rest.mapping;

import hu.mik.prog5.rest.dto.SubscriptionDto;
import hu.mik.prog5.rest.entinty.Subscription;
import org.mapstruct.Mapper;

@Mapper
public interface SubscriptionMapper {

    Subscription toEntity(SubscriptionDto dto);

    SubscriptionDto toDto(Subscription entity);

}
