package hu.mik.prog5.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record SubscriptionDto(
        String id,
        @Email
        @NotBlank
        String email,
        //@Min(18)
        //@NotNull
        //Integer age,
        @JsonProperty("type")
        SubscriptionTypeDto subscriptionType) {
}
