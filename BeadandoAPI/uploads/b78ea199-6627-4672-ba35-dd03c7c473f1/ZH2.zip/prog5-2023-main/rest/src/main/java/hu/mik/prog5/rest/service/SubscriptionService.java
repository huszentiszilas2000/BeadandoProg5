package hu.mik.prog5.rest.service;

import hu.mik.prog5.rest.entinty.Subscription;
import hu.mik.prog5.rest.repository.SubscriptionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SubscriptionService {

    private final SubscriptionRepository repository;

    public Subscription save(Subscription subscription) {
        return this.repository.save(subscription);
    }

}
