package hu.mik.prog5.rest.controller;

import hu.mik.prog5.rest.controller.error.ApiError;
import hu.mik.prog5.rest.controller.service.SubscriptionControllerService;
import hu.mik.prog5.rest.dto.SubscriptionDto;
import hu.mik.prog5.rest.dto.SubscriptionTypeDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@Tag(name = "Subscription API")
@ApiResponse(responseCode = "200", description = "Successfully retrieved")
@ApiResponse(responseCode = "400", description = "THe request could not be understood by the server doe to malformed syntax", content = @Content)
@ApiResponse(responseCode = "500", description = "The request could not be processed", content = @Content(schema = @Schema(implementation = ApiError.class)))
@RestController
@RequiredArgsConstructor
@RequestMapping("/subscription")
public class SubscriptionController extends ResponseEntityExceptionHandler {

    private final SubscriptionControllerService service;

    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "List all subscription types", description = "List all subscription types")
    @GetMapping("/types")
    public SubscriptionTypeDto[] listTypes() {
        //throw new IAmATeapotException();
        return SubscriptionTypeDto.values();
    }

    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Subscribe", description = "Subscribe")
    @PutMapping
    public ResponseEntity<SubscriptionDto> subscribe(@RequestBody @Valid SubscriptionDto subscription) {
        return ResponseEntity.status(HttpStatus.CREATED)
                             .body(this.service.save(subscription));
    }

}
