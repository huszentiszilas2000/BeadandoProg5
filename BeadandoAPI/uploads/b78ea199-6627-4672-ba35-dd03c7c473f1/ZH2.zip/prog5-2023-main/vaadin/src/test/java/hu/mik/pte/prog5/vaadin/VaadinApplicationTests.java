package hu.mik.pte.prog5.vaadin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaadinApplicationTests {

	@Test
	void contextLoads() {
	}

}
