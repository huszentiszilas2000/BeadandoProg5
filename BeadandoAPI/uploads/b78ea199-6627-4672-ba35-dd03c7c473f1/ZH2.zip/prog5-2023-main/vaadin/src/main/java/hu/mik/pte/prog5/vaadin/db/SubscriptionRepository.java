package hu.mik.pte.prog5.vaadin.db;

import hu.mik.pte.prog5.vaadin.entity.Subscription;
import hu.mik.pte.prog5.vaadin.entity.SubscriptionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {

    List<Subscription> findBySubscriptionType(SubscriptionType subscriptionType);

    @Query("SELECT s FROM Subscription s where s.subscriptionType = :type")
    List<Subscription> findBySubscriptionTypeWithJpql(@Param("type") SubscriptionType subscriptionType);

    @Query(value = "SELECT s.* FROM subscription s WHERE s.type = :type", nativeQuery = true)
    List<Subscription> findBySubscriptionTypeWithNativeQuery(@Param("type") SubscriptionType subscriptionType);

}
