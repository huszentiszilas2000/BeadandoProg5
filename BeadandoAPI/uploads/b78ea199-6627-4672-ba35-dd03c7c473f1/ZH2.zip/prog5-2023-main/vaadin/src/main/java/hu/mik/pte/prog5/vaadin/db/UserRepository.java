package hu.mik.pte.prog5.vaadin.db;

import hu.mik.pte.prog5.vaadin.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    User findByUsername(String username);

}
