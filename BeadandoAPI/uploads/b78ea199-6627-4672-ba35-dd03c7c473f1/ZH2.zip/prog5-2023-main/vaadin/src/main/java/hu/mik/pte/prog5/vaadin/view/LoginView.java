package hu.mik.pte.prog5.vaadin.view;

import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.login.LoginForm;
import com.vaadin.flow.component.login.LoginI18n;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.HasDynamicTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;

@Route("login")
@AnonymousAllowed
public class LoginView extends VerticalLayout implements BeforeEnterObserver, HasDynamicTitle {

    private final LoginForm login = new LoginForm();

    public LoginView() {
        this.setSizeFull();

        this.setJustifyContentMode(JustifyContentMode.CENTER);
        this.setAlignItems(Alignment.CENTER);

        this.login.setAction("login");
        this.login.setI18n(this.createLoginI18n());

        this.add(new H1(this.getTranslation("login.title")), this.login);
    }

    private LoginI18n createLoginI18n() {
        LoginI18n i18n = LoginI18n.createDefault();
        i18n.setHeader(new LoginI18n.Header());

        i18n.getHeader()
            .setTitle(this.getTranslation("login.header.title"));
        i18n.getHeader()
            .setDescription(this.getTranslation("login.header.description"));
        i18n.getForm()
            .setUsername(this.getTranslation("login.username"));
        i18n.getForm()
            .setTitle(this.getTranslation("login.title"));
        i18n.getForm()
            .setSubmit(this.getTranslation("login.submit"));
        i18n.getForm()
            .setPassword(this.getTranslation("login.password"));
        i18n.getForm()
            .setForgotPassword(this.getTranslation("login.forgotPassword"));
        i18n.getErrorMessage()
            .setTitle(this.getTranslation("login.error.title"));
        i18n.getErrorMessage()
            .setMessage(this.getTranslation("login.error.message"));

        i18n.setAdditionalInformation(this.getTranslation("login.additionalInformation"));

        return i18n;
    }

    @Override
    public String getPageTitle() {
        return this.getTranslation("login.title");
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (event.getLocation()
                 .getQueryParameters()
                 .getParameters()
                 .containsKey("error")) {
            this.login.setError(true);
        }
    }

}
