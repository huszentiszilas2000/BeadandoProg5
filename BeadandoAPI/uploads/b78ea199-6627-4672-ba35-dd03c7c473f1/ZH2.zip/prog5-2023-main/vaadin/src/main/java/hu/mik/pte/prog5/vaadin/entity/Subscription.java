package hu.mik.pte.prog5.vaadin.entity;


import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Subscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String email;
    @Column(name = "type")
    @Enumerated(EnumType.STRING)
    private SubscriptionType subscriptionType = SubscriptionType.ALL_EMAILS;

}
