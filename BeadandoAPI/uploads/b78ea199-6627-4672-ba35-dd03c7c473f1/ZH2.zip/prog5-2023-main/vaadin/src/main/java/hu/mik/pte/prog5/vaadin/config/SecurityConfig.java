package hu.mik.pte.prog5.vaadin.config;

import com.vaadin.flow.spring.security.VaadinWebSecurity;
import hu.mik.pte.prog5.vaadin.view.LoginView;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends VaadinWebSecurity {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(customizer -> customizer.requestMatchers(new AntPathRequestMatcher("/public/**"))
                                                           .permitAll());

        super.configure(http);

        this.setLoginView(http, LoginView.class);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

/*    @Bean
    public UserDetailsManager userDetailsManager(PasswordEncoder passwordEncoder) {
        return new InMemoryUserDetailsManager(
                User.withUsername("user")
                    .password("Password111")
                    .roles("USER")
                    .passwordEncoder(passwordEncoder::encode)
                    .build(),
                User.withUsername("admin")
                    .password("Password111")
                    .roles("ADMIN", "USER")
                    .passwordEncoder(passwordEncoder::encode)
                    .build());
    }
 */
}
