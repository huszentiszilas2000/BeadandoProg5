package hu.mik.pte.prog5.vaadin.view;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.renderer.TextRenderer;
import com.vaadin.flow.data.validator.EmailValidator;
import com.vaadin.flow.router.HasDynamicTitle;
import com.vaadin.flow.router.Route;
import hu.mik.pte.prog5.vaadin.entity.Subscription;
import hu.mik.pte.prog5.vaadin.entity.SubscriptionType;
import hu.mik.pte.prog5.vaadin.layout.MainLayout;
import hu.mik.pte.prog5.vaadin.service.SubscriptionService;
import jakarta.annotation.security.RolesAllowed;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Route(value = "subscription", layout = MainLayout.class)
@RolesAllowed("USER")
//@PageTitle("Feliratkozás")
public class SubscriptionView extends VerticalLayout implements HasDynamicTitle {

    private final Subscription subscription;

    public SubscriptionView(SubscriptionService subscriptionService) {
        this.subscription = new Subscription();

        var email = new TextField(this.getTranslation("subscription.email"));
        var typeRadio = this.createTypeRadioButton();
        var binder = this.createSubscriptionBinder(email, typeRadio);
        var saveButton = this.createSaveButton(subscriptionService, binder);
        var resetButton = new Button(this.getTranslation("subscription.reset"), e -> binder.readBean(this.subscription));
        var buttonLayout = new HorizontalLayout(saveButton, resetButton);
        this.add(email, typeRadio, buttonLayout);
    }

    private Button createSaveButton(SubscriptionService subscriptionService, Binder<Subscription> binder) {
        return new Button(this.getTranslation("subscription.submit"), event -> {
            try {
                binder.writeBean(this.subscription);
                subscriptionService.save(this.subscription);
                Notification.show(this.getTranslation("subscription.save"));
            } catch (ValidationException e) {
                log.warn(e.getMessage(), e);
                Notification.show(e.getMessage());
            }
        });
    }

    private Binder<Subscription> createSubscriptionBinder(TextField email,
                                                          RadioButtonGroup<SubscriptionType> typeRadio) {
        Binder<Subscription> binder = new Binder<>();
        binder.forField(email)
              .withValidator(new EmailValidator(this.getTranslation("validation.email")))
              .bind(Subscription::getEmail, Subscription::setEmail);
        binder.bind(typeRadio, Subscription::getSubscriptionType, Subscription::setSubscriptionType);
        binder.readBean(this.subscription);
        return binder;
    }

    private RadioButtonGroup<SubscriptionType> createTypeRadioButton() {
        RadioButtonGroup<SubscriptionType> typeRadio = new RadioButtonGroup<>();
        typeRadio.setLabel(this.getTranslation("subscription.type"));
        typeRadio.setRenderer(new TextRenderer<>(label -> this.getTranslation("subscriptionType." + label)));
        typeRadio.setItems(SubscriptionType.values());
        return typeRadio;
    }

    @Override
    public String getPageTitle() {
        return this.getTranslation("subscription.title");
    }

}
