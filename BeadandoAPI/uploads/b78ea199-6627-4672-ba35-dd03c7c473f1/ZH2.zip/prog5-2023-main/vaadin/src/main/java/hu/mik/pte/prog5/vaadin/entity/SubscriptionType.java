package hu.mik.pte.prog5.vaadin.entity;

import lombok.Getter;

@Getter
public enum SubscriptionType {

    ALL_EMAILS("Összes e-mail"),
    DAILY_DIGEST("Napi összesítés");

    private final String label;

    SubscriptionType(String label) {
        this.label = label;
    }

}
