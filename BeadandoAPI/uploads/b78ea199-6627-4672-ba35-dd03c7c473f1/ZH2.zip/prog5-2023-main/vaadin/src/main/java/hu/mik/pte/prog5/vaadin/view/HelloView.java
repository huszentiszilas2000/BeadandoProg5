package hu.mik.pte.prog5.vaadin.view;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import hu.mik.pte.prog5.vaadin.layout.MainLayout;
import jakarta.annotation.security.PermitAll;


@Route(value = "hello", layout = MainLayout.class)
@PageTitle("Hello")
@PermitAll
public class HelloView extends VerticalLayout {

    public HelloView() {
        this.add(new Button("Click me!", e -> Notification.show("Hello World!")));
    }

}
