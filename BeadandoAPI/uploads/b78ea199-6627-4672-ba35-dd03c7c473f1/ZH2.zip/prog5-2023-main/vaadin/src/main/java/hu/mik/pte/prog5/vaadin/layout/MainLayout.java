package hu.mik.pte.prog5.vaadin.layout;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.dom.ThemeList;
import com.vaadin.flow.theme.lumo.Lumo;
import hu.mik.pte.prog5.vaadin.service.SecurityService;

public class MainLayout extends AppLayout {

    private final SecurityService securityService;

    public MainLayout(SecurityService securityService) {
        this.securityService = securityService;

        H1 title = new H1(this.getTranslation("app.title"));

        Button darkThemeBtn = new Button(this.getTranslation("dark.theme"), e -> {
            ThemeList themeList = UI.getCurrent()
                                    .getElement()
                                    .getThemeList();
            if (themeList.contains(Lumo.DARK)) {
                themeList.remove(Lumo.DARK);
            } else {
                themeList.add(Lumo.DARK);
            }
        });

        HorizontalLayout header = new HorizontalLayout();
        if (securityService.getUserDetails() != null) {
            Button logoutBtn = new Button(this.getTranslation("login.logout"), e -> securityService.logout());
            header.add(title, darkThemeBtn, logoutBtn);
        } else {
            header.add(title, darkThemeBtn);
        }

        this.addToNavbar(header);
    }

}
