package hu.mik.pte.prog5.vaadin.service;

import hu.mik.pte.prog5.vaadin.db.SubscriptionRepository;
import hu.mik.pte.prog5.vaadin.entity.Subscription;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class SubscriptionService {

    private final SubscriptionRepository repository;

    public Subscription save(Subscription subscription) {
        log.info("Saving subscription {}", subscription);
        return this.repository.save(subscription);
    }

    public List<Subscription> findAll() {
        return this.repository.findAll();
    }

}
