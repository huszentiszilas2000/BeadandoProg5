package hu.mik.pte.prog5.vaadin.i18n;

import com.vaadin.flow.i18n.I18NProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

@Slf4j
@Component
public class TranslationProvider implements I18NProvider {

    private static final String BUNDLE_PREFIX = "messages";

    public static final Locale DEFAULT = new Locale("", "");
    public static final Locale LOCALE_EN_US = new Locale("en", "US");

    private final List<Locale> locales = List.of(DEFAULT, LOCALE_EN_US);


    @Override
    public List<Locale> getProvidedLocales() {
        return this.locales;
    }

    @Override
    public String getTranslation(String key, Locale locale, Object... params) {
        if (key == null) {
            log.warn("The localization key is null");
            return "";
        }

        ResourceBundle bundle = ResourceBundle.getBundle(BUNDLE_PREFIX, locale);

        String value;
        try {
            value = bundle.getString(key);
        } catch (MissingResourceException e) {
            log.warn("The localization key is not found", e);
            return "!" + locale.getLanguage() + ": " + key;
        }

        if (params.length > 0) {
            return MessageFormat.format(value, params);
        } else {
            return value;
        }
    }

}
