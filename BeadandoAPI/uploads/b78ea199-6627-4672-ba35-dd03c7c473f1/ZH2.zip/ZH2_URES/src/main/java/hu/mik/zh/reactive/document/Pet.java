package hu.mik.zh.reactive.document;

import org.springframework.data.annotation.Id;

import lombok.Data;

@Data
public class Pet {

    @Id
    private String uid;
    private String name;
    private PetSpecies species;

}
